
let argument = process.argv[2]
console.log(`Hello ${argument}`)